/*
 * Blinkenlights_test.h
 *
 *  Created on: Sep 26, 2022
 *      Author: Lenovo
 */
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "Delay.h"

#ifndef BLINKENLIGHTS_TEST_H_
#define BLINKENLIGHTS_TEST_H_
#define C_100ms 5
#ifdef DEBUG
	#define D_COUNT 100000
#else
	#define D_COUNT 62500
#endif
/* Define pins for LEDS  */
#define RED_LED_PIN (18)
#define GREEN_LED_PIN (19)
#define BLUE_LED_PIN (1)

void Int_RGB();
void Delay_test(volatile unsigned int time_del);
void KL25Z_RGB_Flasher(void);
void Call_Delay(volatile unsigned int ntimes);
void LED_ON(int input);
void LED_OFF();
#endif /* BLINKENLIGHTS_TEST_H_ */
