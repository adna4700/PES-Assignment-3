/*
File name: Delay.c
​Description: Assinment 3 PES (Delay). For all definitions of delay funcions
File​ ​Author​ ​Name: Aditi Vijay Nanaware
Tools​ ​used​ ​to​ ​process​ ​the​ ​code​: MCUExpresso IDE, GCC compiler
Referred Google for a few concepts clarification, Dean book (a part of the code)
*/


#include <stdio.h>
#include "board.h"
#include "Blinkenlights_test.h"

/* Defining a delay fucntion for delay
 * Returns void
 * volatile unsigned int time_del: is the iteration count the delay  */
void Delay(volatile unsigned int time_del)
{
	while(time_del--)
	{
		;
	}
}
/* Defining a delay call function for iterating the delay function for required ms
 * Returns void
 * volatile unsigned int ntimes: is the iteration count for which the delay function is called  */
void Call_Delay(volatile unsigned int ntimes)
{
	while(ntimes--)
	{
		Delay(D_COUNT); // this is the calculated value for the required delay
	}
}
