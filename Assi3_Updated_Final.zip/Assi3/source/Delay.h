/*
 * Delay.h
 *
 *  Created on: Sep 26, 2022
 *      Author: Lenovo
 */

#ifndef DELAY_H_
#define DELAY_H_

void Delay(volatile unsigned int time_del);
void Call_Delay(volatile unsigned int ntimes);

#endif /* DELAY_H_ */
