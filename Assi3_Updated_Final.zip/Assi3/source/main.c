/*
File name: main.c
​Description: Assinment 3 PES (main).
File​ ​Author​ ​Name: Aditi Vijay Nanaware
Tools​ ​used​ ​to​ ​process​ ​the​ ​code​: MCUExpresso IDE, GCC compiler
Referred Google for a few concepts clarification, Dean book (a part of the code), Mukta
*/
#include <stdio.h>
#include "board.h"
#include "Blinkenlights_test.h"
#include "TouchSensor.h"
#include "Delay.h"
#include "log.h"


int RED_FLAG, GREEN_FLAG, BLUE_FLAG;

/* The bool stores the status of the LED, initialized to 1  */
 int LED_STAT = 1;
 /* The array contains ON and OFF sequence for infinite loop*/
int  arr[] = {5,5,10,5,20,5,30,5};

int main(void)
{

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    /*initialize the RGB leds*/
    Int_RGB();
    /*the initial sequence of LEDS*/
    KL25Z_RGB_Flasher();
    /*Initializing the touch sensor */
    Touch_Init();
    int index = 0;
    while(1)
    {
    	/* Count stores the arr i.e ON and OFF periods */
    	int count = arr[index];
    	/*  This loop runs for 100ms integrated in count loop*/
    	for(int i=0; i<count;i++)
    	{
    		/* Call the polling function, name updated after suggestion from peer reviewer*/
    		int touch_scanned = Touch_Scan_LH();
    		LOG("%d\n",touch_scanned);
    		/* Switcher is to switch to RED, GREEN or BLUE */
    		 int switcher;
    		    	if((touch_scanned>=50) && (touch_scanned<=300))
    		    		switcher=1;			// RED COLOR
    		    	else if((touch_scanned>350) && (touch_scanned<750))
    		    		switcher=2;			//GREEN COLOR
    		    	else if((touch_scanned>800))
    		    		switcher=3;			//BLUE COLOR
    		    	else
    		    		switcher=0;
    		    	if(LED_STAT == 1)
    		    	{		/* If LED is ON switch the color else remains off*/
    		    	    	switch(switcher)
    		    	    	    {
    		    	    	        case 1:
    		    						LED_ON(RED_LED_PIN);
    		    						RED_FLAG = 1;
    		    						GREEN_FLAG = 0;
    		    						BLUE_FLAG = 0;
    		    						LED_STAT = 1;
    		    	    	            break;

    		    	    	        case 2:
    		    						LED_ON(GREEN_LED_PIN);
    		    						RED_FLAG = 0;
    		    						GREEN_FLAG = 1;
    		    						BLUE_FLAG = 0;
    		    						LED_STAT = 1;
    		    						LED_STAT = 1;
    		    	    	            break;

    		    	    	        case 3:
    		    						LED_ON(BLUE_LED_PIN);
    		    						RED_FLAG = 0;
    		    						GREEN_FLAG = 0;
    		    						BLUE_FLAG = 1;
    		    						LED_STAT = 1;
    		    	    	            break;

    		    	    	        // operator doesn't match any case default white LED
    		    	    	        default:
    		    	    	        	/* Updated this logic after bug found by peer reviewer*/
    		    	    	        	LED_STAT = 1;
    		    	    	        	if(RED_FLAG == 1)
    		    	    	        		LED_ON(RED_LED_PIN);
    		    	    	        	if(GREEN_FLAG == 1)
    		    	    	        		LED_ON(GREEN_LED_PIN);
    		    	    	        	if(BLUE_FLAG == 1)
    		    	    	        		LED_ON(BLUE_LED_PIN);

    		    	    	    }
    		    	    }
    		    	   else
    		    	   {
    		    	     LED_OFF();
    		    	   }
    		    	/* Wait for 100ms*/
    		    	Call_Delay(C_100ms);
    		   }
    	/* Change the LED status for next period*/
    	LED_STAT = ~ LED_STAT;
    	}
    /* Move to next count of period*/
   index ++;
   /* Circular fashion of array iteration*/
    if(index == 8)
    	index = 0;
    return 0 ;
    }
