/*
File name: Blinkenlights.c
​Description: Assinment 3 PES (Blinkenlights). For all definitions of funcions
File​ ​Author​ ​Name: Aditi Vijay Nanaware
Tools​ ​used​ ​to​ ​process​ ​the​ ​code​: MCUExpresso IDE, GCC compiler
Referred Google for a few concepts clarification, Dean book (a part of the code)
*/


#include "Blinkenlights_test.h"
#include <stdio.h>
#include "board.h"

/*This code initialization for RGB LEDs
 * Returns void */
void Int_RGB()
{
	//Enable clock to Port B and Port D For LED blinking
	SIM->SCGC5 = (SIM->SCGC5)|(SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTD_MASK);

	//Make all LED pins GPIO
	PORTB->PCR[RED_LED_PIN] &= ~PORT_PCR_MUX_MASK;
	PORTB->PCR[RED_LED_PIN] |= PORT_PCR_MUX(1);

	PORTB->PCR[GREEN_LED_PIN] &= ~PORT_PCR_MUX_MASK;
	PORTB->PCR[GREEN_LED_PIN] |= PORT_PCR_MUX(1);

	PORTD->PCR[BLUE_LED_PIN] &= ~PORT_PCR_MUX_MASK;
	PORTD->PCR[BLUE_LED_PIN] |=PORT_PCR_MUX(1);

	//Set all LED ports as output ports
	PTB->PDDR |= (1UL << (RED_LED_PIN)) | (1UL << (GREEN_LED_PIN));
	PTD->PDDR |= (1UL << (BLUE_LED_PIN));
}

/* This code flashes initial sequence of led flash
 * Returns void
 * RED for 500 msec, OFF for 100 msec,
GREEN for 500 msec, OFF for 100 msec,
BLUE for 500 msec, OFF for 100 msec
WHITE (that is, RED, GREEN, and BLUE all on) for 100 msec, OFF for 100 msec
WHITE for 100 msec, OFF for 100 MSEC
 * */
void KL25Z_RGB_Flasher(void)
{
			 LED_ON(RED_LED_PIN);
			 Call_Delay(C_100ms*5);
			 LED_OFF();
			 Call_Delay(C_100ms);

			 LED_ON(GREEN_LED_PIN);
			 Call_Delay(C_100ms*5);
			 LED_OFF();
			 Call_Delay(C_100ms);

			 LED_ON(BLUE_LED_PIN);
			 Call_Delay(C_100ms*5);
			 LED_OFF();
			 Call_Delay(C_100ms);

			 LED_ON(0);
			 /* Thus WHITE LED TURNS ON (white looks like light pink on my board
			  * tried to test via switching ON & OFF RGBs, turns out white == light pink )*/
			 Call_Delay(C_100ms);
			 LED_OFF();
			 Call_Delay(C_100ms);


}

/* This function turns on the leds taking int input which isi the LED pin
 * Returns void*/
void LED_ON(int input)
{
	switch(input)
	    {
	        case RED_LED_PIN:
	        	PTB->PCOR = (1UL << (RED_LED_PIN));	   // Turns ON RED LED
	        	PTB->PSOR = (1UL << (GREEN_LED_PIN));	   //Turns OFF GREEN LED
	        	PTD->PSOR = (1UL << (BLUE_LED_PIN));	   //Turns OFF BLUE LED
	            break;

	        case GREEN_LED_PIN:
	        	PTB->PCOR = (1UL << (GREEN_LED_PIN));  //Turns ON GREEN LED
	        	PTD->PSOR = (1UL << (BLUE_LED_PIN));	   //Turns OFF BLUE LED
	        	PTB->PSOR = (1UL << (RED_LED_PIN));    // Turns OFF RED LED
	            break;

	        case BLUE_LED_PIN:
	        	PTD->PCOR = (1UL << (BLUE_LED_PIN));   //TURNS ON BLUE LED
	        	PTB->PSOR = (1UL << (GREEN_LED_PIN));  // Turns OFF GREEN LED
	        	PTB->PSOR = (1UL << (RED_LED_PIN));    // Turns OFF RED LED
	            break;

	        // operator doesn't match any case default white LED
	        default:
	        	PTB->PCOR = (1UL << (RED_LED_PIN));	// Turns ON RED LED
	            PTB->PCOR = (1UL << (GREEN_LED_PIN));  //Turns ON GREEN LED
	        	PTD->PCOR = (1UL << (BLUE_LED_PIN));   //TURNS ON BLUE LED
	    }

}


/* This function turns OFF all the leds
 * Returns void */
void LED_OFF()
{
	PTB->PSOR = (1UL << (RED_LED_PIN));    // Turns OFF RED LED
	PTB->PSOR = (1UL << (GREEN_LED_PIN));  // Turns OFF GREEN LED
	PTD->PSOR = (1UL << (BLUE_LED_PIN));   //Turns OFF BLUE LED
}

